var searchData=
[
  ['resource_20observation',['Resource observation',['../group__observe.html',1,'']]],
  ['rd_2ec',['rd.c',['../rd_8c.html',1,'']]],
  ['rd_5fdelete',['rd_delete',['../rd_8c.html#abaa86756a13f6d7a92ec81544613c9e6',1,'rd.c']]],
  ['rd_5fnew',['rd_new',['../rd_8c.html#aa07a4771cea2265ed6afc6b2ede50b0b',1,'rd.c']]],
  ['rd_5froot_5fsize',['RD_ROOT_SIZE',['../rd_8c.html#ac9ea6ffc23730aa4047d267183e2022f',1,'rd.c']]],
  ['rd_5froot_5fstr',['RD_ROOT_STR',['../rd_8c.html#a27b911a4b90d5982b0e29d7b2f9fc31f',1,'rd.c']]],
  ['rd_5ft',['rd_t',['../structrd__t.html',1,'rd_t'],['../rd_8c.html#a32a1ef100dc3ba849090e69c4fd20ef7',1,'rd_t():&#160;rd.c']]],
  ['ready',['ready',['../client_8c.html#a4adb4fb035eed17910c98225be64ec83',1,'client.c']]],
  ['recvqueue',['recvqueue',['../structcoap__context__t.html#a6230687bf6b5bd5c214bbfb908ff6fa5',1,'coap_context_t']]],
  ['remote',['remote',['../structcoap__queue__t.html#a15ba08baabdadfe7ec9179e7dba5b5f2',1,'coap_queue_t']]],
  ['require_5fetag',['REQUIRE_ETAG',['../etsi__iot__01_8c.html#af0c9a26e65acf758719191e17831e66c',1,'etsi_iot_01.c']]],
  ['resolve_5faddress',['resolve_address',['../client_8c.html#a109f4a0f5a7e52ff35bc7929210afcf5',1,'client.c']]],
  ['resource',['resource',['../coap-observer_8c.html#add13bccf3a03ea896a093ee3634a7428',1,'coap-observer.c']]],
  ['resource_2ec',['resource.c',['../resource_8c.html',1,'']]],
  ['resource_2eh',['resource.h',['../resource_8h.html',1,'']]],
  ['resource_5fkey',['resource_key',['../structcoap__payload__t.html#a85bf44b76aa2c9c123c4ab9b0003c22a',1,'coap_payload_t::resource_key()'],['../structcoap__dynamic__uri__t.html#a1532fe3a9ac6117beda5b882073462d6',1,'coap_dynamic_uri_t::resource_key()']]],
  ['resources',['resources',['../structcoap__context__t.html#aaf441070f9b1f2aea225fc61b60a6bb8',1,'coap_context_t::resources()'],['../rd_8c.html#a6a74f818cd18d9dc8491c3d3afb5ffba',1,'resources():&#160;rd.c']]],
  ['response_5fhandler',['response_handler',['../structcoap__context__t.html#aaeae5156b5641ce3a0bb6d13f5c226d2',1,'coap_context_t']]],
  ['retransmit_5fcnt',['retransmit_cnt',['../structcoap__queue__t.html#aff24f5a43b3d2182535bc7bd2b5f5341',1,'coap_queue_t']]]
];
