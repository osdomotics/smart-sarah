var searchData=
[
  ['init_5fcoap',['init_coap',['../coap-observer_8c.html#a540d113357c1478beb36be0b991dfa01',1,'init_coap():&#160;coap-observer.c'],['../coap-server_8c.html#a540d113357c1478beb36be0b991dfa01',1,'init_coap():&#160;coap-server.c']]],
  ['init_5fresources',['init_resources',['../coap-server_8c.html#a80af26ff7d0088cd5e07de10dd723365',1,'init_resources(coap_context_t *ctx):&#160;coap-server.c'],['../examples_2block_8c.html#a80af26ff7d0088cd5e07de10dd723365',1,'init_resources(coap_context_t *ctx):&#160;block.c'],['../etsi__iot__01_8c.html#a80af26ff7d0088cd5e07de10dd723365',1,'init_resources(coap_context_t *ctx):&#160;etsi_iot_01.c'],['../rd_8c.html#a80af26ff7d0088cd5e07de10dd723365',1,'init_resources(coap_context_t *ctx):&#160;rd.c'],['../server_8c.html#a80af26ff7d0088cd5e07de10dd723365',1,'init_resources(coap_context_t *ctx):&#160;server.c']]]
];
