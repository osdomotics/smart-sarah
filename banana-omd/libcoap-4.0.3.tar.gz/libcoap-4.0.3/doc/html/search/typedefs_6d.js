var searchData=
[
  ['method_5ft',['method_t',['../client_8c.html#ac1d120aa192351ed1caa712eea678a73',1,'client.c']]]
];
