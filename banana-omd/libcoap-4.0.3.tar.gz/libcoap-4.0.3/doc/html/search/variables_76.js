var searchData=
[
  ['value',['value',['../structcoap__option__t.html#aa50001a75531923991a0b0328a1f5e80',1,'coap_option_t::value()'],['../structcoap__attr__t.html#a16e2ca35817107377d85b6dfaf3111f0',1,'coap_attr_t::value()']]],
  ['version',['version',['../structcoap__hdr__t.html#a625254d3cd6447e646851dded82b2333',1,'coap_hdr_t']]]
];
