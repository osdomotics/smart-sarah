var searchData=
[
  ['cacheable',['cacheable',['../structcoap__resource__t.html#a608274b876671be27e2bd099fa112f75',1,'coap_resource_t']]],
  ['clock_5foffset',['clock_offset',['../group__clock.html#gaff0610bcfa58ed2c523edd503d700085',1,'clock_offset():&#160;net.c'],['../group__clock.html#gaff0610bcfa58ed2c523edd503d700085',1,'clock_offset():&#160;net.c']]],
  ['coap_5fcontext',['coap_context',['../coap-observer_8c.html#a1fd390f019e3403f20b18957853f8601',1,'coap_context():&#160;coap-observer.c'],['../coap-server_8c.html#a1fd390f019e3403f20b18957853f8601',1,'coap_context():&#160;coap-server.c']]],
  ['coap_5ferror',['coap_error',['../pdu_8c.html#a48518e7e0d3c7b91a3a4efb3d6eac23c',1,'pdu.c']]],
  ['coap_5fserver_5fprocess',['coap_server_process',['../coap-observer_8c.html#a8856eee5b0724a5b8ab608c2c445333a',1,'coap_server_process():&#160;coap-observer.c'],['../coap-server_8c.html#a8856eee5b0724a5b8ab608c2c445333a',1,'coap_server_process():&#160;coap-server.c']]],
  ['code',['code',['../structerror__desc__t.html#a5de81d35400d8705760ac225630022cc',1,'error_desc_t::code()'],['../structcoap__hdr__t.html#a083d84268cded2de6f0a64858260fc3b',1,'coap_hdr_t::code()'],['../structcontent__type__t.html#aa2dff81a51bf98b334f976cb257e733f',1,'content_type_t::code()']]],
  ['count',['count',['../structUT__hash__bucket.html#a5d20cc12bdcbde360398910eefb45634',1,'UT_hash_bucket']]],
  ['created',['created',['../structcoap__async__state__t.html#a2ce04f273a47df97dfb8af270c858007',1,'coap_async_state_t']]]
];
