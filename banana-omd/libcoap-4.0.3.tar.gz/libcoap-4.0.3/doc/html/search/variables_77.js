var searchData=
[
  ['wait_5fseconds',['wait_seconds',['../client_8c.html#a32ef43b419c476c8473b7000688740ae',1,'client.c']]]
];
